# SpareTech Pro — Free Hosting Setup

This project is designed for a beginner. It uses:
- **Cloudflare Pages** for the website hosting.
- **Supabase** for customer accounts, password recovery, database and messaging.
Both have free options suitable for getting started. Cloudflare Pages supports direct uploads/Git deployments, and Supabase's Free Plan currently includes two free projects. 

## 1. Create your free Supabase project
1. Go to https://supabase.com/
2. Create an account.
3. Create a new project named `sparetech-pro`.
4. Open **SQL Editor**.
5. Copy everything from `supabase/schema.sql` in this ZIP and run it.
6. Open **Project Settings → API**.
7. Copy the **Project URL** and **Publishable/anon key**.
8. Open `app.js`.
9. Replace:
   - `YOUR_SUPABASE_URL`
   - `YOUR_SUPABASE_ANON_KEY`
   with your real values.

Supabase Auth supports email/password sign-up and sign-in, and the reset-password flow is included in this project.

## 2. Create your admin account
1. First create your normal account through the website.
2. In Supabase, open **SQL Editor**.
3. Find your user's ID under Authentication → Users.
4. Run:
```sql
insert into public.admins (user_id) values ('PASTE-YOUR-USER-ID-HERE');
```
Only users in the `admins` table should receive admin privileges.

## 3. Free hosting with Cloudflare Pages
The easiest beginner method is Direct Upload:
1. Go to https://dash.cloudflare.com/
2. Create a free account.
3. Open **Workers & Pages**.
4. Choose **Create application** → **Pages** → **Direct Upload**.
5. Upload the contents of this project folder (or the ZIP after extracting it).
6. Cloudflare will give you a free `*.pages.dev` website address.

Cloudflare's current documentation says Pages supports Direct Upload and Git integration. Static HTML sites are supported.

## 4. Important before publishing
This ZIP is already a working front-end demo with 30 local product illustrations. Real customer registration, password recovery, messaging and admin database management become active after the Supabase steps above.

## 5. Your email
The site displays:
sparetechpro@gmail.com

## 6. Adding real product photographs later
You can replace the 30 SVG illustrations in `assets/` with your own product photographs. Keep the same filenames, or change the product image paths in the database.

## 7. Custom domain later
You can later connect a domain such as `sparetechpro.com` from Cloudflare Pages → your project → Custom domains.


## 8. Admin dashboard
After you have added your own user ID to `public.admins`, open:
`admin.html`

The admin dashboard lets you:
- Add products and prices
- Hide/show products
- Delete products
- Read customer messages
- Reply to customers

For the simplest first version, product images can be entered as an image URL or an existing local path such as `assets/part-01.svg`. We can add a proper Supabase Storage image-upload screen in the next version.
