const PRODUCT_DATA = [
  {
    "id": 1,
    "name": "Brake Disc",
    "price": 45000,
    "currency": "XAF",
    "brand": "Yamaha",
    "model": "YZF-R1",
    "category": "Motorcycle Parts",
    "image": "assets/part-01.svg",
    "description": "Quality brake disc suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 2,
    "name": "Front Brake Caliper",
    "price": 65000,
    "currency": "XAF",
    "brand": "Honda",
    "model": "MT-07",
    "category": "Motorcycle Parts",
    "image": "assets/part-02.svg",
    "description": "Quality front brake caliper suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 3,
    "name": "Clutch Plate",
    "price": 35000,
    "currency": "XAF",
    "brand": "Suzuki",
    "model": "CBR600RR",
    "category": "Motorcycle Parts",
    "image": "assets/part-03.svg",
    "description": "Quality clutch plate suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 4,
    "name": "Chain & Sprocket Kit",
    "price": 55000,
    "currency": "XAF",
    "brand": "Kawasaki",
    "model": "GSX-R750",
    "category": "Motorcycle Parts",
    "image": "assets/part-04.svg",
    "description": "Quality chain & sprocket kit suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 5,
    "name": "Motorcycle Battery",
    "price": 30000,
    "currency": "XAF",
    "brand": "Ducati",
    "model": "Ninja 650",
    "category": "Motorcycle Parts",
    "image": "assets/part-05.svg",
    "description": "Quality motorcycle battery suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 6,
    "name": "Air Filter",
    "price": 28000,
    "currency": "XAF",
    "brand": "KTM",
    "model": "Monster 821",
    "category": "Motorcycle Parts",
    "image": "assets/part-06.svg",
    "description": "Quality air filter suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 7,
    "name": "Oil Filter",
    "price": 42000,
    "currency": "XAF",
    "brand": "BMW",
    "model": "Duke 390",
    "category": "Motorcycle Parts",
    "image": "assets/part-07.svg",
    "description": "Quality oil filter suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 8,
    "name": "Spark Plug",
    "price": 25000,
    "currency": "XAF",
    "brand": "Universal",
    "model": "R 1250 GS",
    "category": "Motorcycle Parts",
    "image": "assets/part-08.svg",
    "description": "Quality spark plug suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 9,
    "name": "Radiator",
    "price": 75000,
    "currency": "XAF",
    "brand": "Yamaha",
    "model": "ER-5",
    "category": "Motorcycle Parts",
    "image": "assets/part-09.svg",
    "description": "Quality radiator suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 10,
    "name": "Headlight",
    "price": 90000,
    "currency": "XAF",
    "brand": "Honda",
    "model": "Universal",
    "category": "Motorcycle Parts",
    "image": "assets/part-10.svg",
    "description": "Quality headlight suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 11,
    "name": "Tail Light",
    "price": 45000,
    "currency": "XAF",
    "brand": "Suzuki",
    "model": "YZF-R1",
    "category": "Motorcycle Parts",
    "image": "assets/part-11.svg",
    "description": "Quality tail light suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 12,
    "name": "Turn Signal",
    "price": 65000,
    "currency": "XAF",
    "brand": "Kawasaki",
    "model": "MT-07",
    "category": "Motorcycle Parts",
    "image": "assets/part-12.svg",
    "description": "Quality turn signal suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 13,
    "name": "Handlebar",
    "price": 35000,
    "currency": "XAF",
    "brand": "Ducati",
    "model": "CBR600RR",
    "category": "Motorcycle Parts",
    "image": "assets/part-13.svg",
    "description": "Quality handlebar suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 14,
    "name": "Rear Shock Absorber",
    "price": 55000,
    "currency": "XAF",
    "brand": "KTM",
    "model": "GSX-R750",
    "category": "Motorcycle Parts",
    "image": "assets/part-14.svg",
    "description": "Quality rear shock absorber suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 15,
    "name": "Front Fork",
    "price": 30000,
    "currency": "XAF",
    "brand": "BMW",
    "model": "Ninja 650",
    "category": "Motorcycle Parts",
    "image": "assets/part-15.svg",
    "description": "Quality front fork suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 16,
    "name": "Foot Peg",
    "price": 28000,
    "currency": "XAF",
    "brand": "Universal",
    "model": "Monster 821",
    "category": "Motorcycle Parts",
    "image": "assets/part-16.svg",
    "description": "Quality foot peg suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 17,
    "name": "Side Mirror",
    "price": 42000,
    "currency": "XAF",
    "brand": "Yamaha",
    "model": "Duke 390",
    "category": "Motorcycle Parts",
    "image": "assets/part-17.svg",
    "description": "Quality side mirror suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 18,
    "name": "Throttle Grip",
    "price": 25000,
    "currency": "XAF",
    "brand": "Honda",
    "model": "R 1250 GS",
    "category": "Motorcycle Parts",
    "image": "assets/part-18.svg",
    "description": "Quality throttle grip suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 19,
    "name": "Brake Lever",
    "price": 75000,
    "currency": "XAF",
    "brand": "Suzuki",
    "model": "ER-5",
    "category": "Motorcycle Parts",
    "image": "assets/part-19.svg",
    "description": "Quality brake lever suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 20,
    "name": "Clutch Lever",
    "price": 90000,
    "currency": "XAF",
    "brand": "Kawasaki",
    "model": "Universal",
    "category": "Motorcycle Parts",
    "image": "assets/part-20.svg",
    "description": "Quality clutch lever suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 21,
    "name": "Gear Shift Lever",
    "price": 45000,
    "currency": "XAF",
    "brand": "Ducati",
    "model": "YZF-R1",
    "category": "Motorcycle Parts",
    "image": "assets/part-21.svg",
    "description": "Quality gear shift lever suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 22,
    "name": "Kick Starter",
    "price": 65000,
    "currency": "XAF",
    "brand": "KTM",
    "model": "MT-07",
    "category": "Motorcycle Parts",
    "image": "assets/part-22.svg",
    "description": "Quality kick starter suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 23,
    "name": "Engine Cover",
    "price": 35000,
    "currency": "XAF",
    "brand": "BMW",
    "model": "CBR600RR",
    "category": "Motorcycle Parts",
    "image": "assets/part-23.svg",
    "description": "Quality engine cover suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 24,
    "name": "Fuel Tank",
    "price": 55000,
    "currency": "XAF",
    "brand": "Universal",
    "model": "GSX-R750",
    "category": "Motorcycle Parts",
    "image": "assets/part-24.svg",
    "description": "Quality fuel tank suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 25,
    "name": "Exhaust Muffler",
    "price": 30000,
    "currency": "XAF",
    "brand": "Yamaha",
    "model": "Ninja 650",
    "category": "Motorcycle Parts",
    "image": "assets/part-25.svg",
    "description": "Quality exhaust muffler suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 26,
    "name": "Wheel Rim",
    "price": 28000,
    "currency": "XAF",
    "brand": "Honda",
    "model": "Monster 821",
    "category": "Motorcycle Parts",
    "image": "assets/part-26.svg",
    "description": "Quality wheel rim suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 27,
    "name": "Motorcycle Tire",
    "price": 42000,
    "currency": "XAF",
    "brand": "Suzuki",
    "model": "Duke 390",
    "category": "Motorcycle Parts",
    "image": "assets/part-27.svg",
    "description": "Quality motorcycle tire suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 28,
    "name": "Drive Chain",
    "price": 25000,
    "currency": "XAF",
    "brand": "Kawasaki",
    "model": "R 1250 GS",
    "category": "Motorcycle Parts",
    "image": "assets/part-28.svg",
    "description": "Quality drive chain suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 29,
    "name": "Speedometer",
    "price": 75000,
    "currency": "XAF",
    "brand": "Ducati",
    "model": "ER-5",
    "category": "Motorcycle Parts",
    "image": "assets/part-29.svg",
    "description": "Quality speedometer suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  },
  {
    "id": 30,
    "name": "Horn",
    "price": 90000,
    "currency": "XAF",
    "brand": "KTM",
    "model": "Universal",
    "category": "Motorcycle Parts",
    "image": "assets/part-30.svg",
    "description": "Quality horn suitable for selected motorcycle applications. Contact SpareTech Pro to confirm fitment, availability and final price."
  }
];
const SUPABASE_URL = "YOUR_SUPABASE_URL";
const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";
const sb = (window.supabase && !SUPABASE_URL.startsWith("YOUR_")) ? window.supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY) : null;

const products = PRODUCT_DATA;
let currentUser = null;

const $ = id => document.getElementById(id);
function money(n){return new Intl.NumberFormat("en-CM").format(n)+" XAF"}
function openModal(html){$("modalContent").innerHTML=html;$("modal").classList.remove("hidden")}
function closeModal(){$("modal").classList.add("hidden")}
window.closeModal=closeModal;

function renderProducts(){
 const q=$("search").value.toLowerCase(), b=$("brandFilter").value, c=$("categoryFilter").value;
 const list=products.filter(p=>(!q||`${p.name} ${p.brand} ${p.model}`.toLowerCase().includes(q))&&(!b||p.brand===b)&&(!c||p.category===c));
 $("count").textContent=`${list.length} part${list.length===1?"":"s"}`;
 $("products").innerHTML=list.map(p=>`<article class="card"><img src="${p.image}" alt="${p.name}"><div class="card-body"><div class="tag">${p.brand} · ${p.model}</div><h3>${p.name}</h3><div class="price">${money(p.price)}</div><div class="card-actions"><button class="btn secondary small" onclick="viewProduct(${p.id})">View part</button><button class="btn primary small" onclick="messageSeller(${p.id})">Message Seller</button></div></div></article>`).join("")||"<p>No parts found.</p>";
}
function setupFilters(){
 [...new Set(products.map(p=>p.brand))].sort().forEach(b=>$("brandFilter").insertAdjacentHTML("beforeend",`<option>${b}</option>`));
 [...new Set(products.map(p=>p.category))].sort().forEach(c=>$("categoryFilter").insertAdjacentHTML("beforeend",`<option>${c}</option>`));
 ["search","brandFilter","categoryFilter"].forEach(id=>$(id).addEventListener("input",renderProducts));
}
function viewProduct(id){
 const p=products.find(x=>x.id===id);
 openModal(`<div class="product-detail"><img src="${p.image}" alt="${p.name}"><div class="tag">${p.brand} · ${p.model}</div><h2>${p.name}</h2><p class="price">${money(p.price)}</p><p>${p.description}</p><button class="btn primary" onclick="messageSeller(${p.id})">Message Seller</button></div>`);
}
window.viewProduct=viewProduct;

function authForm(mode="login"){
 const title=mode==="login"?"Welcome back":mode==="signup"?"Create your account":"Recover your password";
 const body=mode==="reset"?`<p>Enter your email and we'll send you a password-reset link.</p>`:`<p>${mode==="signup"?"Register with your email and a password.":"Sign in to message SpareTech Pro."}</p>`;
 const fields=mode==="signup"?`<input id="authEmail" type="email" placeholder="Email address" required><input id="authPass" type="password" placeholder="Password" minlength="6" required><input id="authConfirm" type="password" placeholder="Confirm password" minlength="6" required>`:mode==="reset"?`<input id="authEmail" type="email" placeholder="Email address" required>`:`<input id="authEmail" type="email" placeholder="Email address" required><input id="authPass" type="password" placeholder="Password" required>`;
 openModal(`<h2>${title}</h2>${body}<div class="form">${fields}<button class="btn primary" onclick="submitAuth('${mode}')">${mode==="login"?"Login":mode==="signup"?"Create account":"Send reset link"}</button><div id="authMsg"></div></div><p>${mode!=="login"?`Already have an account? <span class="link" onclick="openAuth('login')">Login</span>`:`New customer? <span class="link" onclick="openAuth('signup')">Create account</span>`}</p>${mode==="login"?`<span class="link" onclick="openAuth('reset')">Forgot password?</span>`:""}`);
}
function openAuth(mode){authForm(mode)}
window.openAuth=openAuth;

async function submitAuth(mode){
 if(!sb){$("authMsg").innerHTML='<div class="error">Connect this site to Supabase first. See SETUP.md.</div>';return}
 const email=$("authEmail").value.trim();
 if(mode==="reset"){
   const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});
   $("authMsg").innerHTML=error?`<div class="error">${error.message}</div>`:`<div class="success">If an account exists, a reset email has been sent.</div>`; return;
 }
 const pass=$("authPass").value;
 if(mode==="signup"){
   if(pass!==$("authConfirm").value){$("authMsg").innerHTML='<div class="error">Passwords do not match.</div>';return}
   const {error}=await sb.auth.signUp({email,password:pass});
   $("authMsg").innerHTML=error?`<div class="error">${error.message}</div>`:`<div class="success">Account created. Check your email if verification is enabled.</div>`; return;
 }
 const {error}=await sb.auth.signInWithPassword({email,password:pass});
 if(error)$("authMsg").innerHTML=`<div class="error">${error.message}</div>`; else {closeModal(); await refreshUser();}
}
async function refreshUser(){
 if(!sb)return;
 const {data}=await sb.auth.getUser(); currentUser=data.user;
 $("accountBtn").textContent=currentUser?"Account":"Login";
 if(currentUser){$("accountBtn").onclick=showAccount;}else{$("accountBtn").onclick=()=>openAuth("login")}
}
function showAccount(){
 openModal(`<h2>My Account</h2><p>Signed in as <b>${currentUser.email}</b></p><button class="btn secondary" onclick="signOut()">Sign out</button>`);
}
async function signOut(){await sb.auth.signOut();closeModal();refreshUser()}
window.signOut=signOut;

async function messageSeller(id){
 const p=products.find(x=>x.id===id);
 if(!currentUser){openAuth("login");return}
 openModal(`<h2>Message SpareTech Pro</h2><p>Part: <b>${p.name}</b><br>Listed price: <b>${money(p.price)}</b></p><div class="form"><textarea id="messageText" placeholder="Ask about price, availability, delivery or compatibility..."></textarea><button class="btn primary" onclick="sendMessage(${p.id})">Send message</button><div id="msgResult"></div></div>`);
}
window.messageSeller=messageSeller;

async function sendMessage(id){
 if(!sb){$("msgResult").innerHTML='<div class="error">Supabase is not connected yet.</div>';return}
 const text=$("messageText").value.trim(); if(!text)return;
 const {error}=await sb.from("messages").insert({customer_id:currentUser.id,product_id:id,message:text});
 $("msgResult").innerHTML=error?`<div class="error">${error.message}</div>`:`<div class="success">Message sent. SpareTech Pro can now respond.</div>`;
}
window.sendMessage=sendMessage;

async function init(){
 setupFilters();renderProducts();
 $("accountBtn").onclick=()=>openAuth("login");
 if(sb){
   await refreshUser();
   sb.auth.onAuthStateChange((_event,session)=>{currentUser=session?.user||null;refreshUser()});
   const {data}=await sb.from("products").select("*").eq("active",true).order("created_at",{ascending:false});
   if(data && data.length){products.length=0;data.forEach((p,i)=>products.push({...p,image:p.image_url||`assets/part-${String((i%30)+1).padStart(2,"0")}.svg`}));setupFilters();renderProducts();}
 }
}
init();
