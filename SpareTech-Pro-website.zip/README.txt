SPARETECH PRO
================
A motorcycle spare-parts catalogue with customer authentication and seller messaging.

Open index.html for the demo.
Follow SETUP.md to connect Supabase and deploy to Cloudflare Pages.

The 30 starter images are original SVG illustrations included locally, so the site does not depend on image-hosting URLs for the demo.
