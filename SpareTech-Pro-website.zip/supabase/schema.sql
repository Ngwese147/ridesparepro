-- SpareTech Pro database
create extension if not exists pgcrypto;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text default '',
  price numeric(12,2) not null default 0,
  currency text not null default 'XAF',
  brand text not null default 'Universal',
  model text not null default 'Universal',
  category text not null default 'Motorcycle Parts',
  image_url text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  message text not null,
  seller_reply text,
  created_at timestamptz not null default now(),
  replied_at timestamptz
);

alter table public.products enable row level security;
alter table public.admins enable row level security;
alter table public.messages enable row level security;

-- Helper function for admin checks.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists(select 1 from public.admins where user_id = auth.uid());
$$;

-- Products: everyone can read active products; admins can manage.
drop policy if exists "public read active products" on public.products;
create policy "public read active products" on public.products
for select using (active = true or public.is_admin());

drop policy if exists "admins insert products" on public.products;
create policy "admins insert products" on public.products
for insert with check (public.is_admin());

drop policy if exists "admins update products" on public.products;
create policy "admins update products" on public.products
for update using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admins delete products" on public.products;
create policy "admins delete products" on public.products
for delete using (public.is_admin());

-- Messages: customers can create and see their own messages; admins can see/update all.
drop policy if exists "customers create messages" on public.messages;
create policy "customers create messages" on public.messages
for insert with check (auth.uid() = customer_id);

drop policy if exists "customers read own messages" on public.messages;
create policy "customers read own messages" on public.messages
for select using (auth.uid() = customer_id or public.is_admin());

drop policy if exists "admins update messages" on public.messages;
create policy "admins update messages" on public.messages
for update using (public.is_admin()) with check (public.is_admin());

drop policy if exists "admins delete messages" on public.messages;
create policy "admins delete messages" on public.messages
for delete using (public.is_admin());

-- Seed 30 starter products. Images can be replaced with uploaded image URLs later.
insert into public.products (name,price,currency,brand,model,category,image_url)
select * from (values
('Brake Disc',45000,'XAF','Yamaha','YZF-R1','Brakes','assets/part-01.svg'),
('Front Brake Caliper',65000,'XAF','Honda','CBR600RR','Brakes','assets/part-02.svg'),
('Clutch Plate',35000,'XAF','Suzuki','GSX-R750','Engine & Clutch','assets/part-03.svg'),
('Chain & Sprocket Kit',55000,'XAF','Kawasaki','Ninja 650','Transmission','assets/part-04.svg'),
('Motorcycle Battery',30000,'XAF','Ducati','Monster 821','Electrical','assets/part-05.svg'),
('Air Filter',28000,'XAF','KTM','Duke 390','Filters','assets/part-06.svg'),
('Oil Filter',42000,'XAF','BMW','R 1250 GS','Filters','assets/part-07.svg'),
('Spark Plug',25000,'XAF','Universal','Universal','Engine','assets/part-08.svg'),
('Radiator',75000,'XAF','Yamaha','MT-07','Cooling','assets/part-09.svg'),
('Headlight',90000,'XAF','Honda','CBR600RR','Lighting','assets/part-10.svg'),
('Tail Light',45000,'XAF','Suzuki','GSX-R750','Lighting','assets/part-11.svg'),
('Turn Signal',65000,'XAF','Kawasaki','Ninja 650','Lighting','assets/part-12.svg'),
('Handlebar',35000,'XAF','Ducati','Monster 821','Controls','assets/part-13.svg'),
('Rear Shock Absorber',55000,'XAF','KTM','Duke 390','Suspension','assets/part-14.svg'),
('Front Fork',30000,'XAF','BMW','R 1250 GS','Suspension','assets/part-15.svg'),
('Foot Peg',28000,'XAF','Universal','Universal','Controls','assets/part-16.svg'),
('Side Mirror',42000,'XAF','Yamaha','ER-5','Body Parts','assets/part-17.svg'),
('Throttle Grip',25000,'XAF','Honda','CBR600RR','Controls','assets/part-18.svg'),
('Brake Lever',75000,'XAF','Suzuki','GSX-R750','Brakes','assets/part-19.svg'),
('Clutch Lever',90000,'XAF','Kawasaki','Ninja 650','Controls','assets/part-20.svg'),
('Gear Shift Lever',45000,'XAF','Ducati','Monster 821','Transmission','assets/part-21.svg'),
('Kick Starter',65000,'XAF','KTM','Duke 390','Engine','assets/part-22.svg'),
('Engine Cover',35000,'XAF','BMW','R 1250 GS','Engine','assets/part-23.svg'),
('Fuel Tank',55000,'XAF','Yamaha','YZF-R1','Body Parts','assets/part-24.svg'),
('Exhaust Muffler',30000,'XAF','Honda','CBR600RR','Exhaust','assets/part-25.svg'),
('Wheel Rim',28000,'XAF','Suzuki','GSX-R750','Wheels','assets/part-26.svg'),
('Motorcycle Tire',42000,'XAF','Kawasaki','Ninja 650','Wheels','assets/part-27.svg'),
('Drive Chain',25000,'XAF','Ducati','Monster 821','Transmission','assets/part-28.svg'),
('Speedometer',75000,'XAF','KTM','Duke 390','Electrical','assets/part-29.svg'),
('Horn',90000,'XAF','Universal','Universal','Electrical','assets/part-30.svg')
) as v(name,price,currency,brand,model,category,image_url)
where not exists (select 1 from public.products);
